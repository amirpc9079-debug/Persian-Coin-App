package com.parsian.coin.data

import androidx.room.TypeConverter

/**
 * Room به صورت پیش‌فرض از enum پشتیبانی نمی‌کند، بنابراین این Converter
 * برای ذخیره و بازیابی TransactionType به صورت متن استفاده می‌شود.
 */
class Converters {
    @TypeConverter
    fun fromTransactionType(value: TransactionType): String = value.name

    @TypeConverter
    fun toTransactionType(value: String): TransactionType = TransactionType.valueOf(value)
}
