package com.parsian.coin.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.parsian.coin.data.TransactionEntity
import com.parsian.coin.ui.components.LabeledTextField
import com.parsian.coin.ui.components.ReadOnlyField
import com.parsian.coin.ui.components.ScreenPadding
import com.parsian.coin.ui.theme.GoldPrimary
import com.parsian.coin.ui.theme.NavyDark
import com.parsian.coin.util.PersianDateUtil
import com.parsian.coin.viewmodel.TransactionViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SellScreen(
    editId: Long?,
    onBack: () -> Unit,
    viewModel: TransactionViewModel = viewModel()
) {
    var goldPrice by remember { mutableStateOf("") }
    var weight by remember { mutableStateOf("") }
    var laborCost by remember { mutableStateOf("") }
    var customerName by remember { mutableStateOf("") }
    var sellerName by remember { mutableStateOf("") }
    var loadedTransaction by remember { mutableStateOf<TransactionEntity?>(null) }

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val today = PersianDateUtil.getTodayJalaliString()

    LaunchedEffect(editId) {
        if (editId != null && editId != -1L) {
            val tx = viewModel.getById(editId)
            if (tx != null) {
                loadedTransaction = tx
                goldPrice = tx.goldPrice.toString()
                weight = tx.weight.toString()
                laborCost = tx.laborCost.toString()
                customerName = tx.customerName
                sellerName = tx.sellerName
            }
        }
    }

    val isEditMode = editId != null && editId != -1L
    val isFormValid = goldPrice.toLongOrNull() != null &&
        weight.toDoubleOrNull() != null &&
        laborCost.toLongOrNull() != null &&
        customerName.isNotBlank() &&
        sellerName.isNotBlank()

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(if (isEditMode) "ویرایش فروش" else "ثبت فروش سکه") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = NavyDark,
                    titleContentColor = androidx.compose.ui.graphics.Color.White,
                    navigationIconContentColor = androidx.compose.ui.graphics.Color.White
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(ScreenPadding)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            LabeledTextField(
                label = "قیمت هر گرم طلا (ریال)",
                value = goldPrice,
                onValueChange = { goldPrice = it.filter { c -> c.isDigit() } },
                keyboardType = KeyboardType.Number
            )
            LabeledTextField(
                label = "وزن سکه (گرم)",
                value = weight,
                onValueChange = { input ->
                    weight = input.filter { c -> c.isDigit() || c == '.' }
                },
                keyboardType = KeyboardType.Decimal
            )
            LabeledTextField(
                label = "دستمزد (ریال)",
                value = laborCost,
                onValueChange = { laborCost = it.filter { c -> c.isDigit() } },
                keyboardType = KeyboardType.Number
            )
            LabeledTextField(
                label = "نام مشتری (خریدار سکه)",
                value = customerName,
                onValueChange = { customerName = it }
            )
            LabeledTextField(
                label = "نام فروشنده",
                value = sellerName,
                onValueChange = { sellerName = it }
            )
            ReadOnlyField(label = "تاریخ", value = today)

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    viewModel.saveSellTransaction(
                        id = if (isEditMode) editId else null,
                        goldPrice = goldPrice.toLong(),
                        weight = weight.toDouble(),
                        laborCost = laborCost.toLong(),
                        customerName = customerName.trim(),
                        sellerName = sellerName.trim()
                    ) {
                        scope.launch {
                            snackbarHostState.showSnackbar(
                                if (isEditMode) "فروش با موفقیت ویرایش شد" else "فروش با موفقیت ثبت شد"
                            )
                        }
                        if (isEditMode) {
                            onBack()
                        } else {
                            goldPrice = ""
                            weight = ""
                            laborCost = ""
                            customerName = ""
                            sellerName = ""
                        }
                    }
                },
                enabled = isFormValid,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldPrimary,
                    contentColor = NavyDark
                )
            ) {
                Text(if (isEditMode) "ذخیره تغییرات" else "ثبت فروش", fontSize = 16.sp)
            }
        }
    }
}
