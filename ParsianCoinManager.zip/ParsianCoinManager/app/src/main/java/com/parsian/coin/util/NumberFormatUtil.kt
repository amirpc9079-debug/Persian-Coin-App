package com.parsian.coin.util

/**
 * توابع کمکی برای نمایش خوانای اعداد و مبالغ پولی در رابط کاربری فارسی.
 */
object NumberFormatUtil {

    private val persianDigits = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')

    /** تبدیل رقم‌های انگلیسی به فارسی */
    fun toPersianDigits(input: String): String {
        val sb = StringBuilder()
        for (ch in input) {
            if (ch.isDigit()) {
                sb.append(persianDigits[ch - '0'])
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    /** جدا کردن سه‌رقمی اعداد صحیح با کاما، مثلاً 1234567 -> 1,234,567 */
    fun groupThousands(value: Long): String {
        val negative = value < 0
        val s = kotlin.math.abs(value).toString()
        val sb = StringBuilder()
        for (i in s.indices) {
            val posFromEnd = s.length - i
            sb.append(s[i])
            if (posFromEnd > 1 && posFromEnd % 3 == 1) {
                sb.append(',')
            }
        }
        return (if (negative) "-" else "") + sb.toString()
    }

    /** فرمت مبلغ به ریال با اعداد فارسی و جداکننده سه‌رقمی، به همراه واحد "ریال" */
    fun formatRial(value: Long): String {
        return toPersianDigits(groupThousands(value)) + " ریال"
    }

    /** فرمت مبلغ بدون واحد، صرفاً با جداکننده و اعداد فارسی */
    fun formatAmount(value: Long): String {
        return toPersianDigits(groupThousands(value))
    }

    /** فرمت وزن اعشاری (گرم)، حذف صفرهای اضافی */
    fun formatWeight(value: Double): String {
        val text = if (value == value.toLong().toDouble()) {
            value.toLong().toString()
        } else {
            value.toString().trimEnd('0').trimEnd('.')
        }
        return toPersianDigits(text) + " گرم"
    }

    /** فرمت تاریخ شمسی با اعداد فارسی برای نمایش */
    fun formatDateForDisplay(jalaliDate: String): String {
        return toPersianDigits(jalaliDate)
    }
}
