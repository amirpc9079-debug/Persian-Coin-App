package com.parsian.coin.util

import java.util.Calendar

/**
 * تبدیل تاریخ میلادی به شمسی (جلالی) بدون نیاز به هیچ کتابخانه خارجی.
 * الگوریتم استاندارد و رایج تبدیل گرگوری به جلالی.
 */
object PersianDateUtil {

    // تعداد تجمعی روزهای سپری‌شده میلادی پیش از شروع هر ماه (نه تعداد روزهای خود ماه)
    private val gCumulativeDaysBeforeMonth = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)

    /**
     * ورودی: سال، ماه (1-12) و روز میلادی
     * خروجی: Triple(سال شمسی، ماه شمسی، روز شمسی)
     */
    fun gregorianToJalali(gy: Int, gm: Int, gd: Int): Triple<Int, Int, Int> {
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) +
            ((gy2 + 399) / 400) + gd + gCumulativeDaysBeforeMonth[gm - 1]

        var jy = -1595 + (33 * (days / 12053))
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461

        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }

        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + (days / 31)
            jd = 1 + (days % 31)
        } else {
            jm = 7 + ((days - 186) / 30)
            jd = 1 + ((days - 186) % 30)
        }

        return Triple(jy, jm, jd)
    }

    /**
     * تاریخ امروز گوشی را می‌گیرد و به فرمت شمسی "yyyy/MM/dd" برمی‌گرداند.
     * مثلاً: 1405/06/24
     */
    fun getTodayJalaliString(): String {
        val cal = Calendar.getInstance()
        val gy = cal.get(Calendar.YEAR)
        val gm = cal.get(Calendar.MONTH) + 1
        val gd = cal.get(Calendar.DAY_OF_MONTH)
        val (jy, jm, jd) = gregorianToJalali(gy, gm, gd)
        return "%04d/%02d/%02d".format(jy, jm, jd)
    }

    /**
     * فقط بخش سال-ماه از تاریخ شمسی "yyyy/MM/dd" را برمی‌گرداند (برای فیلتر ماهانه در آینده).
     */
    fun yearMonth(jalaliDate: String): String {
        val parts = jalaliDate.split("/")
        return if (parts.size >= 2) "${parts[0]}/${parts[1]}" else jalaliDate
    }
}
