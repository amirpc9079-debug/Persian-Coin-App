package com.parsian.coin.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.parsian.coin.data.AppDatabase
import com.parsian.coin.data.TransactionEntity
import com.parsian.coin.data.TransactionRepository
import com.parsian.coin.data.TransactionType
import com.parsian.coin.util.PersianDateUtil
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.SharingStarted

/** فیلتر نمایش معاملات در صفحه گزارش مالی */
enum class TransactionFilter {
    ALL, BUY_ONLY, SELL_ONLY
}

data class ReportSummary(
    val buyCount: Int = 0,
    val buyTotalWeight: Double = 0.0,
    val buyTotalAmount: Long = 0,
    val sellCount: Int = 0,
    val sellTotalWeight: Double = 0.0,
    val sellTotalAmount: Long = 0,
    val estimatedProfit: Long = 0
)

class TransactionViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: TransactionRepository

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _filter = MutableStateFlow(TransactionFilter.ALL)
    val filter: StateFlow<TransactionFilter> = _filter

    private val allTransactionsFlow: StateFlow<List<TransactionEntity>>

    val filteredTransactions: StateFlow<List<TransactionEntity>>

    val summary: StateFlow<ReportSummary>

    init {
        val dao = AppDatabase.getInstance(application).transactionDao()
        repository = TransactionRepository(dao)

        allTransactionsFlow = repository.allTransactions.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        filteredTransactions = combine(
            allTransactionsFlow, _searchQuery, _filter
        ) { list, query, filterType ->
            list.asSequence()
                .filter { tx ->
                    when (filterType) {
                        TransactionFilter.ALL -> true
                        TransactionFilter.BUY_ONLY -> tx.transactionType == TransactionType.BUY
                        TransactionFilter.SELL_ONLY -> tx.transactionType == TransactionType.SELL
                    }
                }
                .filter { tx ->
                    if (query.isBlank()) {
                        true
                    } else {
                        val q = query.trim()
                        tx.customerName.contains(q, ignoreCase = true) ||
                            tx.sellerName.contains(q, ignoreCase = true) ||
                            tx.date.contains(q)
                    }
                }
                .toList()
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        summary = allTransactionsFlow.map { list ->
            val buys = list.filter { it.transactionType == TransactionType.BUY }
            val sells = list.filter { it.transactionType == TransactionType.SELL }

            val buyTotalAmount = buys.sumOf { it.totalAmount }
            val sellTotalAmount = sells.sumOf { it.totalAmount }

            ReportSummary(
                buyCount = buys.size,
                buyTotalWeight = buys.sumOf { it.weight },
                buyTotalAmount = buyTotalAmount,
                sellCount = sells.size,
                sellTotalWeight = sells.sumOf { it.weight },
                sellTotalAmount = sellTotalAmount,
                estimatedProfit = sellTotalAmount - buyTotalAmount
            )
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = ReportSummary()
        )
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilter(filter: TransactionFilter) {
        _filter.value = filter
    }

    /** محاسبه مبلغ نهایی: (قیمت هر گرم × وزن) + دستمزد */
    fun calculateTotal(goldPrice: Long, weight: Double, laborCost: Long): Long {
        return (goldPrice.toDouble() * weight).toLong() + laborCost
    }

    fun saveBuyTransaction(
        id: Long?,
        goldPrice: Long,
        weight: Double,
        laborCost: Long,
        customerName: String,
        onDone: () -> Unit
    ) {
        val total = calculateTotal(goldPrice, weight, laborCost)
        val entity = TransactionEntity(
            id = id ?: 0,
            transactionType = TransactionType.BUY,
            goldPrice = goldPrice,
            weight = weight,
            laborCost = laborCost,
            customerName = customerName,
            sellerName = "",
            totalAmount = total,
            date = PersianDateUtil.getTodayJalaliString()
        )
        viewModelScope.launch {
            if (id == null) {
                repository.insert(entity)
            } else {
                repository.update(entity)
            }
            onDone()
        }
    }

    fun saveSellTransaction(
        id: Long?,
        goldPrice: Long,
        weight: Double,
        laborCost: Long,
        customerName: String,
        sellerName: String,
        onDone: () -> Unit
    ) {
        val total = calculateTotal(goldPrice, weight, laborCost)
        val entity = TransactionEntity(
            id = id ?: 0,
            transactionType = TransactionType.SELL,
            goldPrice = goldPrice,
            weight = weight,
            laborCost = laborCost,
            customerName = customerName,
            sellerName = sellerName,
            totalAmount = total,
            date = PersianDateUtil.getTodayJalaliString()
        )
        viewModelScope.launch {
            if (id == null) {
                repository.insert(entity)
            } else {
                repository.update(entity)
            }
            onDone()
        }
    }

    fun deleteTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.delete(transaction)
        }
    }

    suspend fun getById(id: Long): TransactionEntity? = repository.getById(id)
}
