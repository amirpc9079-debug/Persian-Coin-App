package com.parsian.coin.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Sell
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.parsian.coin.ui.theme.CardBackground
import com.parsian.coin.ui.theme.GoldPrimary
import com.parsian.coin.ui.theme.NavyDark
import com.parsian.coin.ui.theme.TextSecondary

@Composable
fun HomeScreen(
    onNavigateBuy: () -> Unit,
    onNavigateSell: () -> Unit,
    onNavigateReport: () -> Unit
) {
    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.Top
        ) {
            Spacer(modifier = Modifier.height(28.dp))
            Text(
                text = "مدیریت سکه پارسیان",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = NavyDark
            )
            Text(
                text = "دفتر ثبت خرید و فروش",
                fontSize = 14.sp,
                color = TextSecondary,
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
            )

            HomeMenuCard(
                title = "خرید سکه",
                subtitle = "ثبت خرید سکه از مشتری",
                icon = Icons.Filled.AddShoppingCart,
                onClick = onNavigateBuy
            )
            Spacer(modifier = Modifier.height(16.dp))
            HomeMenuCard(
                title = "فروش سکه",
                subtitle = "ثبت فروش سکه به مشتری",
                icon = Icons.Filled.Sell,
                onClick = onNavigateSell
            )
            Spacer(modifier = Modifier.height(16.dp))
            HomeMenuCard(
                title = "گزارش مالی",
                subtitle = "مشاهده، جست‌وجو و مدیریت معاملات",
                icon = Icons.Filled.Assessment,
                onClick = onNavigateReport
            )
        }
    }
}

@Composable
private fun HomeMenuCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(100.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
            androidx.compose.foundation.layout.Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = title, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = NavyDark)
                    Text(text = subtitle, fontSize = 13.sp, color = TextSecondary, modifier = Modifier.padding(top = 4.dp))
                }
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .padding(start = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = GoldPrimary,
                        modifier = Modifier.size(38.dp)
                    )
                }
            }
        }
    }
}
