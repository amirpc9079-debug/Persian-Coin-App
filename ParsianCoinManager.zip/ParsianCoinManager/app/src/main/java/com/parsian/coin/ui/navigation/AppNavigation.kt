package com.parsian.coin.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.parsian.coin.ui.screens.BuyScreen
import com.parsian.coin.ui.screens.HomeScreen
import com.parsian.coin.ui.screens.ReportScreen
import com.parsian.coin.ui.screens.SellScreen

private object Routes {
    const val HOME = "home"
    const val BUY = "buy?id={id}"
    const val SELL = "sell?id={id}"
    const val REPORT = "report"

    fun buy(id: Long = -1L) = "buy?id=$id"
    fun sell(id: Long = -1L) = "sell?id=$id"
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Routes.HOME) {

        composable(Routes.HOME) {
            HomeScreen(
                onNavigateBuy = { navController.navigate(Routes.buy()) },
                onNavigateSell = { navController.navigate(Routes.sell()) },
                onNavigateReport = { navController.navigate(Routes.REPORT) }
            )
        }

        composable(
            route = Routes.BUY,
            arguments = listOf(navArgument("id") { type = NavType.LongType; defaultValue = -1L })
        ) { backStackEntry ->
            val id = backStackEntry.arguments?.getLong("id") ?: -1L
            BuyScreen(
                editId = id,
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Routes.SELL,
            arguments = listOf(navArgument("id") { type = NavType.LongType; defaultValue = -1L })
        ) { backStackEntry ->
            val id = backStackEntry.arguments?.getLong("id") ?: -1L
            SellScreen(
                editId = id,
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.REPORT) {
            ReportScreen(
                onBack = { navController.popBackStack() },
                onEditBuy = { id -> navController.navigate(Routes.buy(id)) },
                onEditSell = { id -> navController.navigate(Routes.sell(id)) }
            )
        }
    }
}
