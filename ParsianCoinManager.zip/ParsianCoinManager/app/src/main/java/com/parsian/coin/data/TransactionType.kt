package com.parsian.coin.data

/**
 * نوع معامله: خرید سکه از مشتری یا فروش سکه به مشتری
 */
enum class TransactionType {
    BUY,
    SELL
}
