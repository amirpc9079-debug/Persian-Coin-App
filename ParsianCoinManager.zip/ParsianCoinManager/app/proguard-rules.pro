# Default rules - no special configuration needed for this project
