package com.parsian.coin.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * موجودیت اصلی برای ثبت هر معامله خرید یا فروش سکه پارسیان.
 *
 * مبالغ پولی (goldPrice, laborCost, totalAmount) به صورت Long (ریال) ذخیره می‌شوند
 * تا از خطاهای محاسباتی اعشاری جلوگیری شود.
 */
@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val transactionType: TransactionType,

    // قیمت هر گرم طلا (ریال)
    val goldPrice: Long,

    // وزن سکه (گرم) - امکان اعشار
    val weight: Double,

    // دستمزد به صورت مبلغ پولی (ریال)، نه درصد
    val laborCost: Long,

    // نام مشتری (طرف معامله)
    val customerName: String,

    // نام فروشنده - فقط برای معاملات فروش پر می‌شود، برای خرید خالی است
    val sellerName: String = "",

    // مبلغ نهایی معامله = (goldPrice * weight) + laborCost
    val totalAmount: Long,

    // تاریخ شمسی به فرمت yyyy/MM/dd مثلاً 1405/06/24
    val date: String,

    // زمان دقیق ثبت رکورد (میلی‌ثانیه) - صرفاً برای مرتب‌سازی صحیح استفاده می‌شود
    val timestamp: Long = System.currentTimeMillis()
)
