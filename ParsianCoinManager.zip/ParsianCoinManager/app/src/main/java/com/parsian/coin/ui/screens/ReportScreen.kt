package com.parsian.coin.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.parsian.coin.data.TransactionEntity
import com.parsian.coin.data.TransactionType
import com.parsian.coin.ui.theme.ErrorRed
import com.parsian.coin.ui.theme.GoldPrimary
import com.parsian.coin.ui.theme.NavyDark
import com.parsian.coin.ui.theme.SuccessGreen
import com.parsian.coin.ui.theme.TextSecondary
import com.parsian.coin.util.NumberFormatUtil
import com.parsian.coin.viewmodel.TransactionFilter
import com.parsian.coin.viewmodel.TransactionViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportScreen(
    onBack: () -> Unit,
    onEditBuy: (Long) -> Unit,
    onEditSell: (Long) -> Unit,
    viewModel: TransactionViewModel = viewModel()
) {
    val transactions by viewModel.filteredTransactions.collectAsState()
    val summary by viewModel.summary.collectAsState()
    val query by viewModel.searchQuery.collectAsState()
    val filter by viewModel.filter.collectAsState()

    var transactionPendingDelete by remember { mutableStateOf<TransactionEntity?>(null) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("گزارش مالی") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = NavyDark,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("جست‌وجو بر اساس نام مشتری یا تاریخ") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) }
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = filter == TransactionFilter.ALL,
                        onClick = { viewModel.setFilter(TransactionFilter.ALL) },
                        label = { Text("همه") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = GoldPrimary)
                    )
                    FilterChip(
                        selected = filter == TransactionFilter.BUY_ONLY,
                        onClick = { viewModel.setFilter(TransactionFilter.BUY_ONLY) },
                        label = { Text("فقط خرید") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = GoldPrimary)
                    )
                    FilterChip(
                        selected = filter == TransactionFilter.SELL_ONLY,
                        onClick = { viewModel.setFilter(TransactionFilter.SELL_ONLY) },
                        label = { Text("فقط فروش") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = GoldPrimary)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                SummarySection(summary)
            }

            if (transactions.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize().padding(32.dp)) {
                    Text(
                        "معامله‌ای ثبت نشده است",
                        color = TextSecondary,
                        modifier = Modifier.align(androidx.compose.ui.Alignment.Center)
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(
                        horizontal = 16.dp,
                        vertical = 4.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(transactions, key = { it.id }) { tx ->
                        TransactionRow(
                            transaction = tx,
                            onEdit = {
                                if (tx.transactionType == TransactionType.BUY) onEditBuy(tx.id) else onEditSell(tx.id)
                            },
                            onDeleteRequest = { transactionPendingDelete = tx }
                        )
                    }
                    item { Spacer(modifier = Modifier.height(12.dp)) }
                }
            }
        }
    }

    transactionPendingDelete?.let { tx ->
        AlertDialog(
            onDismissRequest = { transactionPendingDelete = null },
            title = { Text("حذف معامله") },
            text = { Text("آیا از حذف این معامله مطمئن هستید؟") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteTransaction(tx)
                    transactionPendingDelete = null
                }) {
                    Text("حذف", color = ErrorRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { transactionPendingDelete = null }) {
                    Text("انصراف")
                }
            }
        )
    }
}

@Composable
private fun SummarySection(summary: com.parsian.coin.viewmodel.ReportSummary) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clipToCard(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            SummaryCard(
                title = "مجموع خرید",
                lines = listOf(
                    "تعداد: ${NumberFormatUtil.toPersianDigits(summary.buyCount.toString())}",
                    "وزن: ${NumberFormatUtil.formatWeight(summary.buyTotalWeight)}",
                    "مبلغ: ${NumberFormatUtil.formatRial(summary.buyTotalAmount)}"
                ),
                accentColor = NavyDark,
                modifier = Modifier.weight(1f)
            )
            SummaryCard(
                title = "مجموع فروش",
                lines = listOf(
                    "تعداد: ${NumberFormatUtil.toPersianDigits(summary.sellCount.toString())}",
                    "وزن: ${NumberFormatUtil.formatWeight(summary.sellTotalWeight)}",
                    "مبلغ: ${NumberFormatUtil.formatRial(summary.sellTotalAmount)}"
                ),
                accentColor = GoldPrimary,
                modifier = Modifier.weight(1f)
            )
        }

        val profit = summary.estimatedProfit
        val profitColor = if (profit >= 0) SuccessGreen else ErrorRed
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    if (profit >= 0) "سود تقریبی" else "زیان تقریبی",
                    fontWeight = FontWeight.SemiBold,
                    color = NavyDark
                )
                Text(
                    NumberFormatUtil.formatRial(kotlin.math.abs(profit)),
                    fontWeight = FontWeight.Bold,
                    color = profitColor
                )
            }
        }
    }
}

private fun Modifier.clipToCard(): Modifier = this

@Composable
private fun SummaryCard(
    title: String,
    lines: List<String>,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = accentColor)
            Spacer(modifier = Modifier.height(6.dp))
            lines.forEach {
                Text(it, fontSize = 12.sp, color = TextSecondary, modifier = Modifier.padding(vertical = 1.dp))
            }
        }
    }
}

@Composable
private fun TransactionRow(
    transaction: TransactionEntity,
    onEdit: () -> Unit,
    onDeleteRequest: () -> Unit
) {
    val isBuy = transaction.transactionType == TransactionType.BUY
    val typeLabel = if (isBuy) "خرید" else "فروش"
    val typeColor = if (isBuy) NavyDark else GoldPrimary

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(typeColor, RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(typeLabel, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        NumberFormatUtil.formatDateForDisplay(transaction.date),
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }
                Row {
                    IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.Edit, contentDescription = "ویرایش", tint = NavyDark)
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(onClick = onDeleteRequest, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.Delete, contentDescription = "حذف", tint = ErrorRed)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            InfoLine("نام مشتری", transaction.customerName)
            if (!isBuy) {
                InfoLine("نام فروشنده", transaction.sellerName)
            }
            InfoLine("قیمت هر گرم", NumberFormatUtil.formatRial(transaction.goldPrice))
            InfoLine("وزن", NumberFormatUtil.formatWeight(transaction.weight))
            InfoLine("دستمزد", NumberFormatUtil.formatRial(transaction.laborCost))

            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("مبلغ نهایی", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = NavyDark)
                Text(
                    NumberFormatUtil.formatRial(transaction.totalAmount),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = typeColor
                )
            }
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 12.sp, color = TextSecondary)
        Text(value, fontSize = 12.sp, color = NavyDark)
    }
}
