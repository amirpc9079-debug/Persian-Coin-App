package com.parsian.coin.ui.theme

import androidx.compose.ui.graphics.Color

// پالت رنگی مناسب کسب‌وکار طلا و سکه: طلایی، سرمه‌ای تیره و کرم روشن
val GoldPrimary = Color(0xFFC9A227)
val GoldPrimaryDark = Color(0xFFA5811C)
val GoldPrimaryLight = Color(0xFFE4C860)

val NavyDark = Color(0xFF1B1F3B)
val NavyMedium = Color(0xFF2A2F55)

val CreamBackground = Color(0xFFFAF7F0)
val CardBackground = Color(0xFFFFFFFF)

val SuccessGreen = Color(0xFF2E7D32)
val ErrorRed = Color(0xFFC62828)
val TextPrimary = Color(0xFF1B1F3B)
val TextSecondary = Color(0xFF6B6B6B)
